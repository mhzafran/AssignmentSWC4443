using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using YouTubeApiProject.Models;

namespace YouTubeApiProject.Controllers
{
    public class HomeController : Controller
    {
        private List<YouTubeVideoModel> _videos = new List<YouTubeVideoModel>
        {
            new YouTubeVideoModel { Title = "Dota 2 WTF Moments 557", ThumbnailUrl = "https://img.youtube.com/vi/IKTt5-JtFZk/maxresdefault.jpg", VideoUrl = "https://www.youtube.com/watch?v=IKTt5-JtFZk" },
            new YouTubeVideoModel { Title = "I Hired a PRO Mira Coach in R6", ThumbnailUrl = "https://img.youtube.com/vi/huuJmnEatoY/maxresdefault.jpg", VideoUrl = "https://www.youtube.com/watch?v=huuJmnEatoY" },
            new YouTubeVideoModel { Title = "Terry's Peaked... (EP 2)", ThumbnailUrl = "https://img.youtube.com/vi/jSBEN_CxfuY/maxresdefault.jpg", VideoUrl = "https://www.youtube.com/watch?v=jSBEN_CxfuY" },
            new YouTubeVideoModel { Title = "Uncle Roger Start A Restaurant... And Break World Record", ThumbnailUrl = "https://img.youtube.com/vi/__xdhaHcBFw/maxresdefault.jpg", VideoUrl = "https://www.youtube.com/watch?v=__xdhaHcBFw" },
            new YouTubeVideoModel { Title = "Trying Korean Fried Chicken for the first time!", ThumbnailUrl = "https://img.youtube.com/vi/qR3FfRqf1WQ/maxresdefault.jpg", VideoUrl = "https://www.youtube.com/watch?v=qR3FfRqf1WQ" }
        };

        public IActionResult Index()
        {
            // Randomly select 3 videos
            var randomVideos = _videos.OrderBy(x => Guid.NewGuid()).Take(3).ToList();
            ViewBag.RandomVideos = randomVideos;
            return View();
        }
    }
}